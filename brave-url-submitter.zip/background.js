// Tiny helper: lets the content script know which tab it is running in,
// so only the tab started by the popup processes the queue.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'whoami') {
    sendResponse({ tabId: sender.tab ? sender.tab.id : null });
  }
  return false;
});
