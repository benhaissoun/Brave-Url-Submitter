(async () => {
  const SUBMIT_URL = 'https://search.brave.com/submit-url';
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const getState = async () => (await chrome.storage.local.get('state')).state;
  const setState = async (s) => chrome.storage.local.set({ state: s });

  let state = await getState();
  if (!state || state.status !== 'running') return;

  // Only the tab started by the popup should work the queue.
  try {
    const me = await chrome.runtime.sendMessage({ type: 'whoami' });
    if (state.tabId && me && me.tabId !== state.tabId) return;
  } catch (e) { /* ignore */ }

  const RE_OK = /thank you|thanks|success|received|submitted|we('| wi)ll (review|crawl)/i;
  const RE_ERR = /error|invalid|not valid|already|too many|rate limit|try again|failed/i;

  const isVisible = (el) => !!(el && (el.offsetParent !== null || el.getClientRects().length));

  function findInput() {
    const cands = [...document.querySelectorAll('input[type="url"], input[type="text"], input:not([type])')]
      .filter((el) => isVisible(el) && !el.disabled && !el.readOnly)
      .filter((el) => el.name !== 'q' && el.id !== 'searchbox' && !el.closest('form[role="search"]'));
    return cands.find((el) => el.type === 'url') || cands[0] || null;
  }

  function findButton(input) {
    const scopes = [input.closest('form'), document].filter(Boolean);
    for (const scope of scopes) {
      const btns = [...scope.querySelectorAll('button, input[type="submit"]')].filter(isVisible);
      const byText = btns.find((b) => /submit/i.test((b.innerText || b.value || '').trim()));
      if (byText) return byText;
      const bySubmitType = btns.find((b) => b.type === 'submit');
      if (bySubmitType) return bySubmitType;
    }
    return null;
  }

  function hasCaptcha() {
    if (document.querySelector(
      'iframe[src*="captcha" i], iframe[src*="turnstile" i], iframe[src*="recaptcha" i], iframe[src*="hcaptcha" i], .g-recaptcha, .h-captcha, .cf-turnstile'
    )) return true;
    return /verify you are (a )?human|are you a robot/i.test(document.body.innerText || '');
  }

  async function waitFor(fn, timeout) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      const v = fn();
      if (v) return v;
      await sleep(400);
    }
    return null;
  }

  function fill(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    input.focus();
    setter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function snippet(text, re) {
    const m = re.exec(text);
    if (!m) return '';
    const s = Math.max(0, m.index - 40);
    return text.slice(s, m.index + 100).replace(/\s+/g, ' ').trim();
  }

  async function waitOutcome(before, input, timeout) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      await sleep(500);
      if (hasCaptcha()) return { type: 'captcha', note: 'CAPTCHA detected' };
      const after = document.body.innerText || '';
      if (RE_ERR.test(after) && !RE_ERR.test(before)) return { type: 'error', note: snippet(after, RE_ERR) };
      if (RE_OK.test(after) && !RE_OK.test(before)) return { type: 'ok', note: snippet(after, RE_OK) };
      if (!document.contains(input) || input.value === '') return { type: 'ok', note: 'form cleared after submit' };
    }
    return { type: 'sent', note: 'no confirmation message detected' };
  }

  async function pauseWith(note) {
    const cur = (await getState()) || state;
    cur.status = 'paused';
    cur.note = note;
    await setState(cur);
  }

  // ---------- main ----------
  if (state.index >= state.queue.length) {
    state.status = 'done';
    await setState(state);
    return;
  }

  const url = state.queue[state.index];
  const idx = state.index;

  const input = await waitFor(findInput, 20000);
  if (!input) return pauseWith('Form field not found on the page. Check the page and press Resume.');
  if (hasCaptcha()) return pauseWith('CAPTCHA detected. Solve it, then press Resume.');

  await sleep(600 + Math.random() * 600);
  fill(input, url);
  await sleep(900 + Math.random() * 600);

  const btn = findButton(input);
  if (!btn) return pauseWith('Submit button not found. Check the page and press Resume.');

  const before = document.body.innerText || '';
  btn.click();

  const outcome = await waitOutcome(before, input, 10000);
  if (outcome.type === 'captcha') return pauseWith('CAPTCHA detected after submit. Solve it, then press Resume (this URL will be retried).');

  // Re-read the state: the user may have paused/stopped meanwhile.
  const cur = await getState();
  if (!cur || cur.status === 'idle' || cur.index !== idx) return;

  cur.results.push({ url, status: outcome.type, note: outcome.note || '', time: new Date().toISOString() });
  cur.index = idx + 1;
  cur.note = '';
  if (cur.index >= cur.queue.length) {
    cur.status = 'done';
    cur.nextAt = null;
    await setState(cur);
    return;
  }
  if (cur.status !== 'running') { await setState(cur); return; }

  const min = Math.max(3, Number(cur.min) || 8);
  const max = Math.max(min, Number(cur.max) || 15);
  const wait = (min + Math.random() * (max - min)) * 1000;
  cur.nextAt = Date.now() + wait;
  await setState(cur);

  // Wait, but stay responsive to Pause/Stop.
  const t0 = Date.now();
  while (Date.now() - t0 < wait) {
    await sleep(1000);
    const s = await getState();
    if (!s || s.status !== 'running') return;
  }
  location.href = SUBMIT_URL;
})();
