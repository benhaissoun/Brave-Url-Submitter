const SUBMIT_URL = 'https://search.brave.com/submit-url';
const $ = (id) => document.getElementById(id);
let pending = [];

// ---------- parsing ----------
function parseUrls(text) {
  text = text.replace(/^\uFEFF/, '');
  const found = [];
  if (/<loc>/i.test(text)) {
    for (const m of text.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/gi)) found.push(m[1]);
  } else {
    for (const line of text.split(/\r?\n/)) {
      const cells = line.split(/[,;\t]/).map((c) => c.trim().replace(/^["']+|["']+$/g, ''));
      const u = cells.find((c) => /^https?:\/\//i.test(c));
      if (u) found.push(u);
    }
  }
  return [...new Set(found)];
}

function setPending(urls) {
  pending = urls;
  $('loaded').textContent = urls.length ? `${urls.length} unique URL(s) ready` : 'No valid URLs found';
}

$('file').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  setPending(parseUrls(await f.text()));
});
$('paste').addEventListener('input', () => setPending(parseUrls($('paste').value)));

// ---------- state helpers ----------
const getState = async () => (await chrome.storage.local.get('state')).state;
const setState = (s) => chrome.storage.local.set({ state: s });

async function openWorkTab(state) {
  if (state.tabId) {
    try {
      await chrome.tabs.get(state.tabId);
      await chrome.tabs.update(state.tabId, { url: SUBMIT_URL, active: true });
      return;
    } catch (e) { /* tab gone, open a new one */ }
  }
  const tab = await chrome.tabs.create({ url: 'about:blank', active: true });
  state.tabId = tab.id;
  await setState(state);
  await chrome.tabs.update(tab.id, { url: SUBMIT_URL });
}

// ---------- buttons ----------
$('start').addEventListener('click', async () => {
  if (!pending.length) { alert('Load a file or paste some URLs first.'); return; }
  const min = Math.max(3, Number($('min').value) || 8);
  const max = Math.max(min, Number($('max').value) || 15);
  const state = { queue: pending, index: 0, results: [], status: 'running', min, max, tabId: null, note: '', nextAt: null };
  await setState(state);
  await openWorkTab(state);
});

$('pause').addEventListener('click', async () => {
  const s = await getState();
  if (s && s.status === 'running') { s.status = 'paused'; s.note = 'Paused by you.'; await setState(s); }
});

$('resume').addEventListener('click', async () => {
  const s = await getState();
  if (!s || s.status === 'done' || s.status === 'running') return;
  s.status = 'running';
  s.note = '';
  s.min = Math.max(3, Number($('min').value) || s.min);
  s.max = Math.max(s.min, Number($('max').value) || s.max);
  await setState(s);
  await openWorkTab(s);
});

$('stop').addEventListener('click', async () => {
  if (confirm('Stop and clear the queue and log?')) await chrome.storage.local.remove('state');
});

$('dl').addEventListener('click', async () => {
  const s = await getState();
  if (!s || !s.results.length) return;
  const esc = (v) => `"${String(v).replace(/"/g, '""')}"`;
  const csv = ['url,status,note,time', ...s.results.map((r) => [r.url, r.status, r.note, r.time].map(esc).join(','))].join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a.download = 'brave-submit-log.csv';
  a.click();
});

$('tab').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') }));

// ---------- rendering ----------
async function render() {
  const s = await getState();
  if (!s) {
    $('status').textContent = 'Idle';
    $('fill').style.width = '0';
    $('note').textContent = '';
    $('log').innerHTML = '';
    return;
  }
  const done = s.index, total = s.queue.length;
  $('fill').style.width = total ? `${Math.round((done / total) * 100)}%` : '0';
  let line = `${s.status.toUpperCase()} — ${done}/${total}`;
  if (s.status === 'running' && s.nextAt && s.nextAt > Date.now()) {
    line += ` — next in ${Math.ceil((s.nextAt - Date.now()) / 1000)}s`;
  }
  $('status').textContent = line;
  $('note').textContent = s.note || '';
  $('log').innerHTML = s.results.slice(-30).reverse()
    .map((r) => `<div class="${r.status}">${r.status}: ${r.url}${r.note ? ' — ' + r.note.slice(0, 60) : ''}</div>`)
    .join('');
}

chrome.storage.onChanged.addListener(render);
setInterval(render, 1000);
render();
